package anotherOne;

public class Main {
}

class PP{
    int n;
    boolean filled=false;
    synchronized void put(int n){
        try{
            while (filled) wait();
        }
    }
}