package p1;
	 public class p10
	{
		public void display()
		{
		System.out.println("I am with parent");
		}

}