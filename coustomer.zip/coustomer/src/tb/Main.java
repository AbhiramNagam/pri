package tb;
class PT extends Thread{
    volatile boolean running=true;
    long click=0;
    PT(int p){
        super.setPriority(p);
        start();
    }
    public void run(){
        while (running) click++;
    }
    public void stopT(){
        running=false;
    }
}

public class Main {
    public static void main(String[] args){
        Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
        PT lo = new PT(Thread.NORM_PRIORITY -2 );
        PT hi = new PT(Thread.NORM_PRIORITY + 2);
        try{
            Thread.sleep(1000);
        }
        catch (Exception e){

        }
        lo.stop();
        hi.stop();
        try {
            lo.join();
            hi.join();
        }
        catch (Exception e){

        }



        System.out.println("Low Priority value : "+lo.click);
        System.out.println("High Priority value : "+hi.click);
    }
}
